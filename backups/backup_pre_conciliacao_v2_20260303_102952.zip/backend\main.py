from fastapi import FastAPI, HTTPException, Depends, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from supabase import Client
from typing import Optional
import os
import json
import shutil
import subprocess
import pandas as pd
import unicodedata
from datetime import datetime, timedelta

print(">>> CARREGANDO MAIN.PY ATUALIZADO COM DEBUG ENDPOINT <<<")
# Database imports
from backend.database import get_db, init_db
from backend.db_helpers import *

app = FastAPI()

# Configuração de CORS
origins = [
    "http://localhost:5173",
    "http://localhost:3000",
    "http://127.0.0.1:5173",
    "*"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize database on startup
import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Helper function for text normalization
def norm(text):
    text = "" if text is None else str(text).strip()
    nfkd = unicodedata.normalize("NFKD", text)
    return "".join(c for c in nfkd if not unicodedata.combining(c)).upper()

@app.on_event("startup")
async def startup_event():
    init_db()
    logger.info("Database initialized (Client ready)")
    logger.info(f"Routes: {[route.path for route in app.routes]}")

# Models
class LoginRequest(BaseModel):
    username: str
    password: str

class LoginResponse(BaseModel):
    token: str
    perfil: str
    perfil: str

class UserCreate(BaseModel):
    nome: str
    senha: str

@app.get("/api/health")
def health_check(db: Client = Depends(get_db)):
    try:
        # Test connection by listing dre_financeiro (limit 1)
        db.table("dre_financeiro").select("id").limit(1).execute()
        db_status = "connected"
    except Exception as e:
        print(f"Health check failed: {e}")
        db_status = "disconnected"
    
    return {"status": "ok", "database": db_status}

@app.get("/api/dre/financeiro")
def get_dre_financeiro(context: str = "flux", db: Client = Depends(get_db)):
    try:
        if context == "coop":
            return get_dre_financeiro_coop(db)
        return get_dre_financeiro_data(db)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/dre/gerencial")
def get_dre_gerencial(context: str = "flux", db: Client = Depends(get_db)):
    try:
        if context == "coop":
            return get_dre_gerencial_coop(db)
        return get_dre_gerencial_data(db)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/ranking_farmacias")
def get_ranking_farmacias(context: str = "flux", debug: bool = False, db: Client = Depends(get_db)):
    """
    Retorna ranking de farmacias com metricas calculadas (apenas cenario competencia).
    - Receita: entradas por farmacia/mes.
    - Despesa rateada: despesas operacionais do mes (sem Simples) rateadas proporcionalmente a receita do mes.
    - Imposto rateado: Simples pago no mes seguinte rateado proporcionalmente a receita do mes; se ausente, estimado pela aliquota media historica.
    """
    try:
        if context == "coop":
            financeiro = get_dre_financeiro_coop(db)
        else:
            financeiro = get_dre_financeiro_data(db)
        if not financeiro:
            return []

        df_fin = pd.DataFrame(financeiro)

        rename_map = {
            "entrada_saida": "entrada_saida",
            "valor": "valor",
            "centro_custo": "centro_custo",
            "tipo_custo": "tipo_custo",
            "plano_contas": "plano_contas",
            "mes_ano": "mes_ano",
            "mes_nome": "mes_nome",
        }
        df_fin = df_fin.rename(columns=rename_map)



        # Base de impostos para rateio (Flux: Simples; Coop: ISS)
        if context == "coop":
            imposto_mask = df_fin["plano_contas"].str.contains("ISS", na=False, case=False)
        else:
            imposto_mask = df_fin["plano_contas"].str.contains("SIMPLES NACIONAL", na=False, case=False)
        df_imposto_base = df_fin[imposto_mask & (df_fin["entrada_saida"].apply(norm) == "SAIDA")]

        # Normalizacoes
        df_fin["tipo_custo_norm"] = df_fin["tipo_custo"].apply(norm)
        df_fin["plano_norm"] = df_fin["plano_contas"].apply(norm)
        df_fin["entrada_norm"] = df_fin["entrada_saida"].apply(norm)
        df_fin["data_mov_dt"] = pd.to_datetime(df_fin.get("data_mov"), errors="coerce")
        df_fin["mes_ano"] = df_fin["mes_ano"].apply(lambda x: str(x).strip() if x is not None else x)

        df_base = df_fin.copy()
        df_base = df_base[~df_base["tipo_custo_norm"].isin(["NAO OPERACIONAL", "DISTRIBUICAO", "TRANSFERENCIA"])]
        df_base["mes_ano"] = df_base["mes_ano"].apply(lambda x: str(x).strip() if x is not None else x)

        # Base completa para despesas (mantém NAO ESPECIFICADO)
        df_base_all = df_base.copy()

        # Referência Flux (apenas quando context=coop): garante consistência por mês (ENTREGAS)
        # na lista de lojas "que faturaram" entre Flux e Cooperativa.
        allowed_pairs_flux = None
        if context == "coop":
            try:
                flux_ref = get_dre_financeiro_data(db) or []
                df_flux = pd.DataFrame(flux_ref)
                if not df_flux.empty:
                    df_flux = df_flux.rename(columns=rename_map)
                    df_flux["plano_norm"] = df_flux["plano_contas"].apply(norm)
                    df_flux["entrada_norm"] = df_flux["entrada_saida"].apply(norm)
                    df_flux["centro_norm"] = df_flux["centro_custo"].apply(norm)
                    df_flux["mes_ano"] = df_flux["mes_ano"].apply(lambda x: str(x).strip() if x is not None else x)
                    allowed_pairs_flux = df_flux[
                        (df_flux["entrada_norm"] == "ENTRADA")
                        & (df_flux["plano_norm"].str.contains("ENTREGAS", na=False))
                        & (df_flux["centro_norm"] != "NAO ESPECIFICADO")
                    ][["centro_custo", "mes_ano", "mes_nome"]].drop_duplicates()
            except Exception as e:
                logger.warning(f"[ranking] Falha ao carregar referência Flux para context=coop: {e}")

        # Receitas: filtra centros elegíveis (entradas com ENTREGAS) e remove NAO ESPECIFICADO apenas para receitas
        df_fin = df_base[df_base["centro_custo"].apply(lambda x: norm(x) != "NAO ESPECIFICADO")]
        entrada_mask = df_fin["entrada_norm"] == "ENTRADA"
        entregas_mask = df_fin["plano_contas"].apply(norm).str.contains("ENTREGAS", na=False)
        centros_elegiveis = set(df_fin[entrada_mask & entregas_mask]["centro_custo"].tolist())
        df_fin = df_fin[df_fin["centro_custo"].isin(centros_elegiveis)]

        if allowed_pairs_flux is not None and not allowed_pairs_flux.empty:
            allowed_centros = set(allowed_pairs_flux["centro_custo"].tolist())
            centros_elegiveis = centros_elegiveis.intersection(allowed_centros)
            df_fin = df_fin[df_fin["centro_custo"].isin(centros_elegiveis)]

        # Receita por mês (para rateio): usar apenas ENTREGAS (centro de custo é confiável só para esse plano)
        receitas_entregas = df_fin[
            (df_fin["entrada_norm"] == "ENTRADA")
            & (df_fin["plano_norm"].str.contains("ENTREGAS", na=False))
        ].copy()
        if allowed_pairs_flux is not None and not allowed_pairs_flux.empty:
            # Basear a lista (farmácia, mês) no Flux e preencher faltantes do Coop com 0
            coop_sum = (
                receitas_entregas.groupby(["centro_custo", "mes_ano"])["valor"]
                .sum()
                .reset_index()
            )
            base_pairs = allowed_pairs_flux[["centro_custo", "mes_ano", "mes_nome"]].copy()
            receitas_entregas = base_pairs.merge(coop_sum, on=["centro_custo", "mes_ano"], how="left")
            receitas_entregas["valor"] = receitas_entregas["valor"].fillna(0)
        receita_total_mes = receitas_entregas.groupby("mes_ano")["valor"].sum().to_dict()

        # Despesas operacionais do mês (sem imposto): separar em
        # - Diretas (com centro de custo elegível): entram 100% na farmácia
        # - Overhead (sem centro ou não elegível): rateado proporcionalmente à receita do mês
        # Excluir categorias que começam com "RECEITAS " (classificação incorreta no Excel)
        df_sem_imposto_all = df_base_all[~df_base_all["plano_norm"].str.contains("SIMPLES NACIONAL|ISS", na=False)]
        df_despesas_all = df_sem_imposto_all[
            (df_sem_imposto_all["entrada_norm"] == "SAIDA")
            & (~df_sem_imposto_all["plano_norm"].str.startswith("RECEITAS "))
        ].copy()

        def is_centro_elegivel(x):
            return (norm(x) != "NAO ESPECIFICADO") and (x in centros_elegiveis)

        despesas_diretas_mask = df_despesas_all["centro_custo"].apply(is_centro_elegivel)
        df_despesas_diretas = df_despesas_all[despesas_diretas_mask].copy()
        df_despesas_overhead = df_despesas_all[~despesas_diretas_mask].copy()

        overhead_var_mes = (
            df_despesas_overhead[df_despesas_overhead["tipo_custo_norm"] == "VARIAVEL"]
            .groupby("mes_ano")["valor"]
            .sum()
            .abs()
            .to_dict()
        )
        overhead_fix_mes = (
            df_despesas_overhead[df_despesas_overhead["tipo_custo_norm"] == "FIXO"]
            .groupby("mes_ano")["valor"]
            .sum()
            .abs()
            .to_dict()
        )

        df_despesas_diretas["valor_abs"] = df_despesas_diretas["valor"].abs()
        diretas_var = (
            df_despesas_diretas[df_despesas_diretas["tipo_custo_norm"] == "VARIAVEL"]
            .groupby(["centro_custo", "mes_ano"])["valor_abs"]
            .sum()
            .to_dict()
        )
        diretas_fix = (
            df_despesas_diretas[df_despesas_diretas["tipo_custo_norm"] == "FIXO"]
            .groupby(["centro_custo", "mes_ano"])["valor_abs"]
            .sum()
            .to_dict()
        )

        if debug:
            logger.info(f"[ranking] receita_total_mes: {receita_total_mes}")
            logger.info(f"[ranking] overhead_var_mes: {overhead_var_mes}")
            logger.info(f"[ranking] overhead_fix_mes: {overhead_fix_mes}")
            logger.info(f"[ranking] diretas_var (sample): {list(diretas_var.items())[:10]}")
            logger.info(f"[ranking] diretas_fix (sample): {list(diretas_fix.items())[:10]}")

        # Impostos pagos por mes de pagamento (caixa)
        impostos_mes_pagamento = df_imposto_base.groupby("mes_ano")["valor"].sum().abs().to_dict()

        # Impostos de competencia: mes anterior ao pagamento
        def prev_month_str(mes_ano: str) -> str:
            try:
                from datetime import datetime, timedelta

                dt = datetime.strptime(mes_ano + "-01", "%Y-%m-%d")
                prev = dt.replace(day=1) - timedelta(days=1)
                return prev.strftime("%Y-%m")
            except Exception:
                return mes_ano

        impostos_competencia = {}
        for row in df_imposto_base.to_dict(orient="records"):
            m_pag = row.get("mes_ano")
            valor = abs(row.get("valor", 0) or 0)
            m_comp = prev_month_str(m_pag)
            impostos_competencia[m_comp] = impostos_competencia.get(m_comp, 0) + valor
        if debug:
            logger.info(f"[ranking] impostos_competencia (mes -> valor): {impostos_competencia}")

        # Aliquota media historica (pagamento -> competencia anterior)
        # Importante: ignorar meses de competencia sem receita no dataset, para nao inflar a aliquota.
        total_imp = 0.0
        total_rec_comp = 0.0
        for comp_mes, imp in impostos_competencia.items():
            rec = float(receita_total_mes.get(comp_mes, 0) or 0)
            if rec > 0:
                total_imp += float(imp or 0)
                total_rec_comp += rec
        aliquota_media = (total_imp / total_rec_comp) if total_rec_comp else 0

        total_receita_geral = receitas_entregas["valor"].sum()

        ranking = []
        grouped = receitas_entregas.groupby(["centro_custo", "mes_ano", "mes_nome"])
        for (farmacia, mes_ano, mes_nome), df_farm in grouped:
            receita_bruta = df_farm["valor"].sum()
            if receita_bruta <= 0:
                # No contexto cooperativa, mantemos a linha para manter a mesma lista de lojas do Flux por mês
                # (o valor pode ficar 0 quando não houver rateio no relatório da cooperativa).
                if not (context == "coop" and allowed_pairs_flux is not None and not allowed_pairs_flux.empty):
                    continue
            receita_mes_total = receita_total_mes.get(mes_ano, 0)

            peso = (receita_bruta / receita_mes_total) if receita_mes_total > 0 else 0

            # Despesas: diretas + overhead rateado (proporcional à receita)
            desp_dir_var = float(diretas_var.get((farmacia, mes_ano), 0) or 0)
            desp_dir_fix = float(diretas_fix.get((farmacia, mes_ano), 0) or 0)
            desp_ov_var = float(overhead_var_mes.get(mes_ano, 0) or 0) * peso
            desp_ov_fix = float(overhead_fix_mes.get(mes_ano, 0) or 0) * peso

            despesa_var_total = desp_dir_var + desp_ov_var
            despesa_fix_total = desp_dir_fix + desp_ov_fix

            # Imposto de competencia: pagamento do mes seguinte; se nao houver, estimar pela aliquota media historica
            imposto_comp_mes = impostos_competencia.get(mes_ano, 0)
            imposto_estimado = False
            if imposto_comp_mes == 0 and aliquota_media and receita_mes_total > 0:
                imposto_comp_mes = receita_mes_total * aliquota_media
                imposto_estimado = True

            imposto_comp = 0
            if peso > 0 and imposto_comp_mes > 0:
                imposto_comp = imposto_comp_mes * peso

            despesas_operacionais = despesa_var_total + despesa_fix_total
            total_despesas = despesas_operacionais + imposto_comp

            # Margem de contribuição: receita - despesas variáveis (não inclui fixas)
            margem_contribuicao = receita_bruta - despesa_var_total
            margem_contribuicao_pct = (margem_contribuicao / receita_bruta * 100) if receita_bruta else 0
            rol_comp = receita_bruta - total_despesas
            rentabilidade_comp = (rol_comp / receita_bruta * 100) if receita_bruta else 0
            participacao_lucro = (receita_bruta / total_receita_geral * 100) if total_receita_geral else 0

            ranking.append(
                {
                    "farmacia": farmacia,
                    "mes_nome": mes_nome,
                    "mes_ano": mes_ano,
                    "receita_bruta": float(receita_bruta),
                    "despesa_variavel_rateada": float(despesa_var_total),
                    "despesa_fixa_rateada": float(despesa_fix_total),
                    "despesas_rateadas_operacionais": float(despesas_operacionais),
                    "despesa_rateada_total": float(total_despesas),
                    "despesa_total_competencia": float(total_despesas),
                    "despesa_total": float(total_despesas),
                    "imposto_rateado_competencia": float(imposto_comp),
                    "imposto_rateado": float(imposto_comp),
                    "imposto_estimado": bool(imposto_estimado),
                    "margem_contribuicao": float(margem_contribuicao),
                    "margem_contribuicao_pct": float(margem_contribuicao_pct),
                    "rol": float(rol_comp),
                    "rol_competencia": float(rol_comp),
                    "rentabilidade": float(rentabilidade_comp),
                    "rentabilidade_competencia": float(rentabilidade_comp),
                    "participacao_lucro": float(participacao_lucro),
                }
            )

        ranking.sort(key=lambda x: x["receita_bruta"], reverse=True)

        if debug:
            return {
                "ranking": ranking,
                "debug": {
                    "receita_total_mes": receita_total_mes,
                    "overhead_var_mes": overhead_var_mes,
                    "overhead_fix_mes": overhead_fix_mes,
                    "diretas_var_count": len(diretas_var),
                    "diretas_fix_count": len(diretas_fix),
                    "impostos_competencia": impostos_competencia,
                    "aliquota_media": aliquota_media,
                },
            }

        return ranking

    except Exception as e:
        print(f"Error in ranking: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/ranking_farmacias_consolidado")
def get_ranking_farmacias_consolidado(debug: bool = False, db: Client = Depends(get_db)):
    """
    Consolida Flux + Cooperativa por farmácia e mês, usando rateio por operação:
    - Flux é calculado pelo endpoint /api/ranking_farmacias?context=flux
    - Coop é calculado pelo endpoint /api/ranking_farmacias?context=coop
    O "Total" é a soma dos componentes já rateados por operação.
    """
    try:
        flux = get_ranking_farmacias(context="flux", debug=False, db=db) or []
        coop = get_ranking_farmacias(context="coop", debug=False, db=db) or []

        def to_float(x):
            try:
                return float(x or 0)
            except Exception:
                return 0.0

        def get_op_fields(row):
            # Campos mais estáveis no retorno atual do ranking
            receita = to_float(row.get("receita_bruta"))
            desp_op = to_float(row.get("despesas_rateadas_operacionais"))
            imposto = to_float(row.get("imposto_rateado"))
            imposto_estimado = bool(row.get("imposto_estimado"))
            return receita, desp_op, imposto, imposto_estimado

        merged = {}

        def upsert(op_key: str, row: dict):
            farmacia_raw = row.get("farmacia") or ""
            mes_ano = row.get("mes_ano") or ""
            mes_nome = row.get("mes_nome") or ""
            # Unificar nomes com/sem acento entre operacoes (ex.: FARMACIA vs FARMÁCIA)
            farmacia_key = norm(farmacia_raw)
            k = (farmacia_key, mes_ano)
            if k not in merged:
                merged[k] = {
                    "farmacia": farmacia_raw,
                    "mes_ano": mes_ano,
                    "mes_nome": mes_nome,
                    # Flux
                    "receita_flux": 0.0,
                    "despesas_op_flux": 0.0,
                    "imposto_flux": 0.0,
                    "imposto_estimado_flux": False,
                    # Coop
                    "receita_coop": 0.0,
                    "despesas_op_coop": 0.0,
                    "imposto_coop": 0.0,
                    "imposto_estimado_coop": False,
                }
            # Preferir mes_nome não vazio (ex.: quando uma operação não tem)
            if mes_nome and not merged[k].get("mes_nome"):
                merged[k]["mes_nome"] = mes_nome
            # Preferir label da cooperativa (normalmente vem com acentos e melhor para exibir)
            if op_key == "coop" and farmacia_raw:
                merged[k]["farmacia"] = farmacia_raw

            receita, desp_op, imposto, imposto_estimado = get_op_fields(row)
            if op_key == "flux":
                merged[k]["receita_flux"] = receita
                merged[k]["despesas_op_flux"] = desp_op
                merged[k]["imposto_flux"] = imposto
                merged[k]["imposto_estimado_flux"] = imposto_estimado
            else:
                merged[k]["receita_coop"] = receita
                merged[k]["despesas_op_coop"] = desp_op
                merged[k]["imposto_coop"] = imposto
                merged[k]["imposto_estimado_coop"] = imposto_estimado

        for r in flux:
            upsert("flux", r)
        for r in coop:
            upsert("coop", r)

        rows = []
        for (farmacia, mes_ano), r in merged.items():
            receita_total = to_float(r.get("receita_flux")) + to_float(r.get("receita_coop"))
            despesas_op_total = to_float(r.get("despesas_op_flux")) + to_float(r.get("despesas_op_coop"))
            imposto_total = to_float(r.get("imposto_flux")) + to_float(r.get("imposto_coop"))
            total_despesas = despesas_op_total + imposto_total
            rol = receita_total - total_despesas
            rentabilidade = (rol / receita_total * 100) if receita_total else 0.0
            margem_contrib = receita_total - despesas_op_total
            margem_contrib_pct = (margem_contrib / receita_total * 100) if receita_total else 0.0

            rows.append(
                {
                    **r,
                    "receita_total": float(receita_total),
                    "despesas_op_total": float(despesas_op_total),
                    "imposto_total": float(imposto_total),
                    "despesa_total": float(total_despesas),
                    "rol": float(rol),
                    "rentabilidade": float(rentabilidade),
                    "margem_contribuicao": float(margem_contrib),
                    "margem_contribuicao_pct": float(margem_contrib_pct),
                    "imposto_estimado": bool(r.get("imposto_estimado_flux") or r.get("imposto_estimado_coop")),
                }
            )

        total_receita_geral = sum(to_float(x.get("receita_total")) for x in rows) or 0.0
        for r in rows:
            r["participacao_receita"] = (
                (to_float(r.get("receita_total")) / total_receita_geral * 100) if total_receita_geral else 0.0
            )

        rows.sort(key=lambda x: x.get("receita_total", 0.0), reverse=True)

        if debug:
            return {
                "ranking": rows,
                "debug": {
                    "count_flux": len(flux),
                    "count_coop": len(coop),
                    "count_merged": len(rows),
                },
            }

        return rows
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


def _iso_date(s: str) -> str:
    try:
        return datetime.strptime(s, "%Y-%m-%d").date().isoformat()
    except Exception:
        raise HTTPException(status_code=400, detail="Data inválida, use YYYY-MM-DD")


def _week_bounds_from_monday(monday_iso: str) -> tuple[str, str]:
    d = datetime.strptime(monday_iso, "%Y-%m-%d").date()
    if d.weekday() != 0:
        raise HTTPException(status_code=400, detail="week_start deve ser uma segunda-feira (YYYY-MM-DD)")
    return d.isoformat(), (d + timedelta(days=6)).isoformat()


@app.get("/api/coop/conciliacao_entregas/weeks")
def coop_conciliacao_weeks(db: Client = Depends(get_db)):
    """
    Lista semanas disponíveis (Seg-Dom) para conciliação na Cooperativa.
    Base: tabela coop_conciliacao_entregas.
    """
    try:
        # Se a tabela não existir, dar mensagem clara
        try:
            db.table("coop_conciliacao_entregas").select("id").limit(1).execute()
        except Exception as e:
            raise HTTPException(
                status_code=500,
                detail=f"Tabela coop_conciliacao_entregas inexistente. Execute backend/coop_conciliacao_entregas.sql no Supabase. Erro: {e}",
            )

        # Buscar semanas únicas. A tabela tem muitas linhas por semana, então paginamos e
        # coletamos as primeiras N semanas distintas (ordenando pelas mais recentes).
        unique = set()
        out = []
        start = 0
        chunk = 1000
        max_weeks = 120
        while len(out) < max_weeks:
            batch = (
                db.table("coop_conciliacao_entregas")
                .select("semana_inicio, semana_fim")
                .not_.is_("semana_fim", "null")
                .order("semana_inicio", desc=True)
                .range(start, start + chunk - 1)
                .execute()
                .data
            ) or []
            if not batch:
                break
            for r in batch:
                si = r.get("semana_inicio")
                sf = r.get("semana_fim")
                if not si or not sf:
                    continue
                k = f"{si}|{sf}"
                if k in unique:
                    continue
                unique.add(k)
                out.append({"semana_inicio": si, "semana_fim": sf})
                if len(out) >= max_weeks:
                    break
            start += chunk

        out.sort(key=lambda x: (x.get("semana_inicio") or ""))
        return out
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/coop/conciliacao_entregas")
def coop_conciliacao_entregas(week_start: str, farmacias: Optional[str] = None, only_divergent: bool = False, db: Client = Depends(get_db)):
    """
    Conciliação semanal (Seg-Dom) para Cooperativa:
    - Receita: ENTRADA + RECEITAS COM ENTREGAS (somente RATEIO)
    - A pagar: SAÍDA + PAGAMENTO DE ENTREGADORES (somente RATEIO)
    - Controle: total MOV (VALOR MOV.CONTA) vs soma RATEIO para pagamento de entregadores
    Semana é definida pelo fim do intervalo em REFERENTE (ETL já grava semana_inicio/semana_fim).
    """
    try:
        ws = _iso_date(week_start)
        ws, we = _week_bounds_from_monday(ws)

        # Base query: semana
        q = (
            db.table("coop_conciliacao_entregas")
            .select(
                "semana_inicio,semana_fim,entrada_saida,plano_contas,centro_custo_final,valor_mov,valor_rateado,linha_tipo"
            )
            .eq("semana_inicio", ws)
            .eq("semana_fim", we)
        )

        if farmacias:
            farm_list = [f.strip() for f in farmacias.split(",") if f.strip()]
            if farm_list:
                q = q.in_("centro_custo_final", farm_list)

        rows = q.execute().data or []
        df = pd.DataFrame(rows)
        if df.empty:
            return {"week_start": ws, "week_end": we, "rows": []}

        df["plano_norm"] = df["plano_contas"].apply(norm)
        df["entrada_norm"] = df["entrada_saida"].apply(norm)
        df["linha_norm"] = df["linha_tipo"].apply(norm)
        df["centro"] = df["centro_custo_final"].fillna("Não Especificado")

        # Receita entregas (rateio)
        df_rec = df[
            (df["entrada_norm"] == "ENTRADA")
            & (df["plano_norm"] == "RECEITAS COM ENTREGAS")
            & (df["linha_norm"] == "RATEIO")
            & (df["centro"].apply(norm) != "NAO ESPECIFICADO")
        ].copy()
        rec_por_farm = df_rec.groupby("centro")["valor_rateado"].sum().to_dict()

        # Pagamento entregadores (rateio)
        df_pay_rate = df[
            (df["entrada_norm"] == "SAIDA")
            & (df["plano_norm"] == "PAGAMENTO DE ENTREGADORES")
            & (df["linha_norm"] == "RATEIO")
            & (df["centro"].apply(norm) != "NAO ESPECIFICADO")
        ].copy()
        pay_por_farm = df_pay_rate.groupby("centro")["valor_rateado"].sum().to_dict()

        # Controle do pagamento: movimento (mov) vs rateio
        df_pay_mov = df[
            (df["entrada_norm"] == "SAIDA")
            & (df["plano_norm"] == "PAGAMENTO DE ENTREGADORES")
            & (df["linha_norm"] == "MOV")
        ].copy()
        total_mov = float(df_pay_mov["valor_mov"].fillna(0).sum() or 0)
        total_rateado = float(df_pay_rate["valor_rateado"].fillna(0).sum() or 0)
        diff_rateio = total_mov - total_rateado

        # Base de farmácias: união entre receitas e pagamentos
        farms = set(rec_por_farm.keys()) | set(pay_por_farm.keys())
        out_rows = []
        for f in sorted(farms):
            receita = float(rec_por_farm.get(f, 0) or 0)
            pago = float(pay_por_farm.get(f, 0) or 0)
            saldo = receita - pago
            pct = (pago / receita * 100) if receita else 0.0
            out_rows.append(
                {
                    "farmacia": f,
                    "receita_entregas": receita,
                    "pagamento_entregadores": pago,
                    "saldo": saldo,
                    "pct_repasse": pct,
                }
            )

        if only_divergent:
            out_rows = [r for r in out_rows if abs((r["saldo"] or 0)) > 0.01]

        out_rows.sort(key=lambda x: x.get("receita_entregas", 0.0), reverse=True)

        return {
            "week_start": ws,
            "week_end": we,
            "controle": {
                "pagamento_mov_total": total_mov,
                "pagamento_rateado_total": total_rateado,
                "pagamento_diff": diff_rateio,
            },
            "rows": out_rows,
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


def _fetch_all_filtered(db: Client, table: str, select: str, build_query_fn, chunk: int = 1000, max_rows: int = 200000):
    all_rows = []
    start = 0
    while True:
        q = build_query_fn(db.table(table).select(select))
        batch = q.range(start, start + chunk - 1).execute().data or []
        all_rows.extend(batch)
        if len(batch) < chunk:
            break
        start += chunk
        if start >= max_rows:
            break
    return all_rows


@app.get("/api/coop/conciliacao_entregas/cash_weeks")
def coop_conciliacao_cash_weeks(db: Client = Depends(get_db)):
    """
    Lista semanas (Seg-Dom) disponíveis para a visão de CAIXA:
    - usa DATA MOVIMENTO das ENTRADAS de RECEITAS COM ENTREGAS (RATEIO).
    """
    try:
        rows = _fetch_all_filtered(
            db,
            "coop_conciliacao_entregas",
            "data_mov",
            lambda q: q.eq("entrada_saida", "ENTRADA")
            .eq("plano_contas", "RECEITAS COM ENTREGAS")
            .eq("linha_tipo", "RATEIO")
            .not_.is_("data_mov", "null")
            .order("data_mov", desc=True),
            chunk=1000,
            max_rows=50000,
        )
        df = pd.DataFrame(rows)
        if df.empty:
            return []
        df["data_mov"] = pd.to_datetime(df["data_mov"], errors="coerce")
        df = df.dropna(subset=["data_mov"])
        if df.empty:
            return []

        # gerar semanas Seg-Dom a partir das datas existentes
        unique_weeks = set()
        out = []
        for d in sorted(df["data_mov"].dt.date.unique()):
            monday = d - timedelta(days=d.weekday())
            sunday = monday + timedelta(days=6)
            k = f"{monday.isoformat()}|{sunday.isoformat()}"
            if k in unique_weeks:
                continue
            unique_weeks.add(k)
            out.append({"week_start": monday.isoformat(), "week_end": sunday.isoformat()})
        out.sort(key=lambda x: x["week_start"])
        return out
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/coop/conciliacao_entregas/pay_days")
def coop_conciliacao_pay_days(month: Optional[str] = None, db: Client = Depends(get_db)):
    """
    Lista dias de pagamento (rodadas) disponíveis:
    - usa DATA MOVIMENTO das SAÍDAS de PAGAMENTO DE ENTREGADORES (MOV) para evitar duplicidades.
    """
    try:
        month_start = None
        month_end = None
        if month:
            try:
                y, m = month.split("-")
                y = int(y)
                m = int(m)
                if m < 1 or m > 12:
                    raise ValueError("mês inválido")
                from calendar import monthrange

                last_day = monthrange(y, m)[1]
                month_start = datetime(y, m, 1).date().isoformat()
                month_end = datetime(y, m, last_day).date().isoformat()
            except Exception:
                raise HTTPException(status_code=400, detail="Parâmetro month inválido. Use YYYY-MM (ex.: 2025-01).")

        unique = set()
        out = []
        start = 0
        chunk = 1000
        # Não limitar em 180 dias: precisamos mostrar desde o início do ano (ex.: janeiro/2025).
        # Observação: filtros com "SAÍDA" podem falhar por encoding em query params; como
        # plano_contas + linha_tipo já isolam o dataset, omitimos esse filtro.
        max_rows = 200000
        while True:
            def build(q):
                q = (
                    q.select("data_mov")
                    .eq("plano_contas", "PAGAMENTO DE ENTREGADORES")
                    .eq("linha_tipo", "MOV")
                    .order("data_mov", desc=True)
                )
                if month_start and month_end:
                    q = q.gte("data_mov", month_start).lte("data_mov", month_end)
                return q

            batch = (
                build(db.table("coop_conciliacao_entregas"))
                .range(start, start + chunk - 1)
                .execute()
                .data
            ) or []
            if not batch:
                break
            for r in batch:
                d = r.get("data_mov")
                if not d:
                    continue
                if d in unique:
                    continue
                unique.add(d)
                out.append({"pay_day": d})
            start += chunk
            if start >= max_rows:
                break
        out.sort(key=lambda x: x["pay_day"])
        return out
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/coop/conciliacao_entregas/pay_months")
def coop_conciliacao_pay_months(db: Client = Depends(get_db)):
    """
    Lista meses (YYYY-MM) que possuem rodadas de pagamento registradas.
    Base: DATA MOVIMENTO das SAÍDAS de PAGAMENTO DE ENTREGADORES (MOV).
    """
    try:
        rows = _fetch_all_filtered(
            db,
            "coop_conciliacao_entregas",
            "data_mov",
            lambda q: q.eq("plano_contas", "PAGAMENTO DE ENTREGADORES")
            .eq("linha_tipo", "MOV")
            .not_.is_("data_mov", "null")
            .order("data_mov", desc=True),
            chunk=1000,
            max_rows=200000,
        )
        if not rows:
            return []
        df = pd.DataFrame(rows)
        if df.empty or "data_mov" not in df.columns:
            return []
        df["data_mov"] = pd.to_datetime(df["data_mov"], errors="coerce")
        df = df.dropna(subset=["data_mov"])
        if df.empty:
            return []
        months = sorted(set(df["data_mov"].dt.strftime("%Y-%m").tolist()))
        return [{"month": m} for m in months]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/coop/conciliacao_entregas/report")
def coop_conciliacao_report(cash_week_start: str, pay_day: str, farmacias: Optional[str] = None, only_divergent: bool = False, db: Client = Depends(get_db)):
    """
    Relatório operacional para aprovação na quinta:
    - Receita (Caixa): o que entrou na semana Seg-Dom (DATA MOVIMENTO), RATEIO de ENTREGAS.
    - Pagamento (Rodada): o que será pago no dia selecionado (DATA MOVIMENTO), RATEIO de PAGAMENTO DE ENTREGADORES.
    - Mostra também quais ciclos (periodo_inicio/fim do REFERENTE) estão incluídos na rodada.
    """
    try:
        ws = _iso_date(cash_week_start)
        ws, we = _week_bounds_from_monday(ws)
        pd_day = _iso_date(pay_day)

        farm_list = None
        if farmacias:
            farm_list = [f.strip() for f in farmacias.split(",") if f.strip()]

        def apply_farm_filter(q):
            if farm_list:
                return q.in_("centro_custo_final", farm_list)
            return q

        # Receita (caixa semana): ENTRADA + ENTREGAS + RATEIO, por data_mov no intervalo
        rec_rows = _fetch_all_filtered(
            db,
            "coop_conciliacao_entregas",
            "centro_custo_final,valor_rateado",
            lambda q: apply_farm_filter(q)
            .eq("entrada_saida", "ENTRADA")
            .eq("plano_contas", "RECEITAS COM ENTREGAS")
            .eq("linha_tipo", "RATEIO")
            .gte("data_mov", ws)
            .lte("data_mov", we),
            chunk=1000,
            max_rows=200000,
        )
        df_rec = pd.DataFrame(rec_rows)
        if not df_rec.empty:
            df_rec["centro"] = df_rec["centro_custo_final"].fillna("Não Especificado")
            df_rec = df_rec[df_rec["centro"].apply(norm) != "NAO ESPECIFICADO"]
            df_rec["valor_rateado"] = pd.to_numeric(df_rec["valor_rateado"], errors="coerce").fillna(0.0)
        rec_por_farm = (df_rec.groupby("centro")["valor_rateado"].sum().to_dict() if not df_rec.empty else {})

        # Pagamento (rodada): SAÍDA + PAGAMENTO DE ENTREGADORES + RATEIO, por data_mov == pd_day
        pay_rate_rows = _fetch_all_filtered(
            db,
            "coop_conciliacao_entregas",
            "centro_custo_final,valor_rateado,periodo_inicio,periodo_fim",
            lambda q: apply_farm_filter(q)
            .eq("plano_contas", "PAGAMENTO DE ENTREGADORES")
            .eq("linha_tipo", "RATEIO")
            .eq("data_mov", pd_day),
            chunk=1000,
            max_rows=200000,
        )
        df_pay = pd.DataFrame(pay_rate_rows)
        if not df_pay.empty:
            df_pay["centro"] = df_pay["centro_custo_final"].fillna("Não Especificado")
            df_pay = df_pay[df_pay["centro"].apply(norm) != "NAO ESPECIFICADO"]
            df_pay["valor_rateado"] = pd.to_numeric(df_pay["valor_rateado"], errors="coerce").fillna(0.0)
        pay_por_farm = (df_pay.groupby("centro")["valor_rateado"].sum().to_dict() if not df_pay.empty else {})

        ciclos_por_farm = {}
        if not df_pay.empty:
            for f, g in df_pay.groupby("centro"):
                ciclos = (
                    g[["periodo_inicio", "periodo_fim"]]
                    .dropna()
                    .drop_duplicates()
                    .to_dict(orient="records")
                )
                ciclos_por_farm[f] = ciclos

        # Receita (ciclos apurados pagos na rodada): soma ENTRADAS (ENTREGAS/RATEIO) dentro dos
        # períodos (periodo_inicio/fim) que apareceram no pagamento do dia, por farmácia.
        # Importante: para bater com o relatório base, usamos o PERÍODO APURADO (REFERENTE -> periodo_inicio/fim)
        # nas linhas de RECEITAS, e não o DATA MOVIMENTO (que pode ocorrer dias depois).
        receita_ciclos_por_farm: dict[str, float] = {}
        if ciclos_por_farm:
            df_cycles = df_pay[["centro", "periodo_inicio", "periodo_fim"]].dropna()
            if not df_cycles.empty:
                df_cycles["pi"] = pd.to_datetime(df_cycles["periodo_inicio"].astype(str).str.slice(0, 10), errors="coerce")
                df_cycles["pf"] = pd.to_datetime(df_cycles["periodo_fim"].astype(str).str.slice(0, 10), errors="coerce")
                df_cycles = df_cycles.dropna(subset=["pi", "pf"])

            if df_cycles is not None and not df_cycles.empty:
                min_pi = df_cycles["pi"].dt.date.min().isoformat()
                max_pf = df_cycles["pf"].dt.date.max().isoformat()

                rec_cycle_rows = _fetch_all_filtered(
                    db,
                    "coop_conciliacao_entregas",
                    "centro_custo_final,valor_rateado,periodo_inicio,periodo_fim",
                    lambda q: apply_farm_filter(q)
                    .eq("plano_contas", "RECEITAS COM ENTREGAS")
                    .eq("linha_tipo", "RATEIO")
                    .not_.is_("periodo_inicio", "null")
                    .not_.is_("periodo_fim", "null")
                    .gte("periodo_fim", min_pi)
                    .lte("periodo_fim", max_pf),
                    chunk=1000,
                    max_rows=400000,
                )

                df_rec_cycle = pd.DataFrame(rec_cycle_rows)
                if not df_rec_cycle.empty:
                    df_rec_cycle["centro"] = df_rec_cycle["centro_custo_final"].fillna("Não Especificado")
                    df_rec_cycle = df_rec_cycle[df_rec_cycle["centro"].apply(norm) != "NAO ESPECIFICADO"]
                    df_rec_cycle["valor_rateado"] = pd.to_numeric(df_rec_cycle["valor_rateado"], errors="coerce").fillna(0.0)
                    df_rec_cycle["pi"] = pd.to_datetime(df_rec_cycle["periodo_inicio"].astype(str).str.slice(0, 10), errors="coerce")
                    df_rec_cycle["pf"] = pd.to_datetime(df_rec_cycle["periodo_fim"].astype(str).str.slice(0, 10), errors="coerce")
                    df_rec_cycle = df_rec_cycle.dropna(subset=["pi", "pf"])
                    df_rec_cycle["pi"] = df_rec_cycle["pi"].dt.date
                    df_rec_cycle["pf"] = df_rec_cycle["pf"].dt.date

                for f, ciclos in ciclos_por_farm.items():
                    if df_rec_cycle.empty:
                        receita_ciclos_por_farm[f] = 0.0
                        continue
                    df_farm = df_rec_cycle[df_rec_cycle["centro"] == f]
                    if df_farm.empty:
                        receita_ciclos_por_farm[f] = 0.0
                        continue

                    wanted = set()
                    for c in ciclos or []:
                        pi = c.get("periodo_inicio")
                        pf = c.get("periodo_fim")
                        if not pi or not pf:
                            continue
                        di = pd.to_datetime(str(pi)[:10], errors="coerce")
                        df_ = pd.to_datetime(str(pf)[:10], errors="coerce")
                        if pd.isna(di) or pd.isna(df_):
                            continue
                        di = di.date()
                        df_ = df_.date()
                        if di > df_:
                            di, df_ = df_, di
                        wanted.add((di, df_))

                    if not wanted:
                        receita_ciclos_por_farm[f] = 0.0
                        continue

                    keys = list(zip(df_farm["pi"].tolist(), df_farm["pf"].tolist()))
                    mask = pd.Series(keys).isin(wanted).values
                    receita_ciclos_por_farm[f] = float(df_farm.loc[mask, "valor_rateado"].sum())

        # Controle do pagamento: MOV total vs RATEIO total no dia
        pay_mov_rows = _fetch_all_filtered(
            db,
            "coop_conciliacao_entregas",
            "valor_mov",
            lambda q: q.eq("plano_contas", "PAGAMENTO DE ENTREGADORES")
            .eq("linha_tipo", "MOV")
            .eq("data_mov", pd_day),
            chunk=1000,
            max_rows=200000,
        )
        df_mov = pd.DataFrame(pay_mov_rows)
        mov_total = float(pd.to_numeric(df_mov.get("valor_mov"), errors="coerce").fillna(0).sum() if not df_mov.empty else 0.0)
        rate_total = float(pd.to_numeric(df_pay.get("valor_rateado"), errors="coerce").fillna(0).sum() if not df_pay.empty else 0.0)
        diff = mov_total - rate_total

        farms = set(rec_por_farm.keys()) | set(pay_por_farm.keys())
        out_rows = []
        for f in sorted(farms):
            receita_caixa = float(rec_por_farm.get(f, 0) or 0)
            receita_ciclos = float(receita_ciclos_por_farm.get(f, 0) or 0)
            pago = float(pay_por_farm.get(f, 0) or 0)
            saldo_caixa = receita_caixa - pago
            saldo_ciclos = receita_ciclos - pago
            pct_caixa = (pago / receita_caixa * 100) if receita_caixa else 0.0
            pct_ciclos = (pago / receita_ciclos * 100) if receita_ciclos else 0.0
            out_rows.append(
                {
                    "farmacia": f,
                    "receita_semana_caixa": receita_caixa,
                    "receita_ciclos_apurados": receita_ciclos,
                    "pagamento_quinta": pago,
                    "saldo": saldo_ciclos,
                    "saldo_caixa": saldo_caixa,
                    "pct_repasse": pct_ciclos,
                    "pct_repasse_caixa": pct_caixa,
                    "ciclos": ciclos_por_farm.get(f, []),
                }
            )

        if only_divergent:
            out_rows = [r for r in out_rows if abs((r["saldo"] or 0)) > 0.01]

        out_rows.sort(key=lambda x: x.get("receita_ciclos_apurados", 0.0), reverse=True)

        totals = {
            "receita_semana_caixa": float(sum(rec_por_farm.values()) if rec_por_farm else 0.0),
            "receita_ciclos_apurados": float(sum(receita_ciclos_por_farm.values()) if receita_ciclos_por_farm else 0.0),
            "pagamento_quinta": float(sum(pay_por_farm.values()) if pay_por_farm else 0.0),
        }
        totals["saldo"] = totals["receita_ciclos_apurados"] - totals["pagamento_quinta"]
        totals["saldo_caixa"] = totals["receita_semana_caixa"] - totals["pagamento_quinta"]

        return {
            "cash_week_start": ws,
            "cash_week_end": we,
            "pay_day": pd_day,
            "totals": totals,
            "controle": {
                "pagamento_mov_total": mov_total,
                "pagamento_rateado_total": rate_total,
                "pagamento_diff": diff,
            },
            "rows": out_rows,
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/predictive/forecast")
def get_forecast(context: str = "flux", db: Client = Depends(get_db)):
    """Retorna séries de receita e despesa projetadas"""
    try:
        predictive_data = get_predictive_data_coop(db) if context == "coop" else get_predictive_data(db)
        
        if not predictive_data:
            return {
                "mrr_historico": {},
                "mrr_forecast": None,
                "despesa_forecast": None,
                "receitas_por_tipo": []
            }
        
        return {
            "mrr_historico": predictive_data.get('mrr_historico', {}),
            "mrr_forecast": predictive_data.get('mrr_forecast'),
            "despesa_forecast": predictive_data.get('despesa_forecast'),
            "receitas_por_tipo": predictive_data.get('receitas_por_tipo', [])
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/valuation/data")
def get_valuation(context: str = "flux", db: Client = Depends(get_db)):
    """Retorna dados de valuation"""
    try:
        predictive_data = get_predictive_data_coop(db) if context == "coop" else get_predictive_data(db)
        
        if not predictive_data:
            return {
                "arr_current": 0,
                "arr_projected": 0,
                "scenarios": {}
            }
        
        return predictive_data.get('valuation', {})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ===== UPLOAD DE DADOS =====
@app.post("/api/upload")
async def upload_file(
    file: UploadFile = File(...),
    context: str = "flux",
    db: Client = Depends(get_db),
):
    """Upload de arquivo Excel para atualizar dados do dashboard (Flux ou Cooperativa)."""
    try:
        # Validar extensão
        if not file.filename.endswith(('.xlsx', '.xls')):
            raise HTTPException(status_code=400, detail="Apenas arquivos Excel (.xlsx, .xls) são permitidos")
        
        base_dir = os.getcwd()
        data_dir = os.path.join(base_dir, "data")
        os.makedirs(data_dir, exist_ok=True)
        file_path = os.path.join(data_dir, file.filename)
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        
        # Escolhe ETL conforme contexto
        if context == "coop":
            etl_path = os.path.join(base_dir, "etl", "process_coop.py")
        else:
            etl_path = os.path.join(base_dir, "etl", "process_data.py")

        result = subprocess.run(["python", etl_path, file_path], capture_output=True, text=True)
        if result.returncode != 0:
            raise HTTPException(status_code=500, detail=f"Erro ao processar dados: {result.stderr}")
        
        return {"message": "Arquivo enviado e processado com sucesso", "context": context}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ===== GESTÃO DE USUÁRIOS =====
@app.post("/api/users")
async def create_user_endpoint(user: UserCreate, db: Client = Depends(get_db)):
    """Criar novo usuário (apenas admin)"""
    try:
        existing = get_user(db, user.nome)
        if existing:
            raise HTTPException(status_code=400, detail="Usuário já existe")

        perfil = getattr(user, "perfil", "operacional")
        created = create_user(db, user.nome, user.senha, perfil)

        return {"message": "Usuário criado com sucesso", "user": created}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/users")
async def list_users_endpoint(db: Client = Depends(get_db)):
    """Listar usuários (apenas admin)"""
    try:
        users = list_users(db)
        return {"users": users}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/api/users/{username}")
async def delete_user_endpoint(username: str, db: Client = Depends(get_db)):
    """Excluir usuário (apenas admin)"""
    try:
        success = delete_user(db, username)
        if not success:
            raise HTTPException(status_code=404, detail="Usuário não encontrado")
        
        return {"message": f"Usuário {username} excluído com sucesso"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/login", response_model=LoginResponse)
def login(request: LoginRequest, db: Client = Depends(get_db)):
    # Mock Auth - In production, use proper authentication
    user = get_user(db, request.username)
    
    if user and user['senha'] == request.password:
        perfil = user.get("perfil", "operacional")
        return LoginResponse(token="mock-jwt-token-12345", perfil=perfil)
    else:
        raise HTTPException(status_code=401, detail="Credenciais inválidas")

# Mount Static Files (Frontend Build)
# The Dockerfile copies frontend build to /app/dist; fallback to local ./dist when rodando local.
static_dir = "/app/dist"
local_dist = os.path.join(os.path.dirname(__file__), "..", "dist")
frontend_dist = os.path.join(os.path.dirname(__file__), "..", "frontend", "dist")

def has_assets(path: str) -> bool:
    return os.path.exists(os.path.join(path, "assets"))

if has_assets(static_dir):
    pass
elif has_assets(local_dist):
    static_dir = local_dist
elif has_assets(frontend_dist):
    static_dir = frontend_dist
else:
    static_dir = None

if static_dir:
    app.mount("/assets", StaticFiles(directory=os.path.join(static_dir, "assets")), name="assets")

@app.get("/api/debug_ranking")
def debug_ranking(db: Client = Depends(get_db)):
    try:
        financeiro = get_dre_financeiro_data(db)
        df_fin = pd.DataFrame(financeiro)
        
        # Normalizações básicas
        cols_map = {
            "DATA MOV.": "data_mov",
            "DATA": "data_mov",
            "VALOR": "valor",
            "PARCEIRO": "parceiro",
            "CENTRO DE CUSTO": "centro_custo",
            "PLANO DE CONTAS": "plano_contas",
            "TIPO_CUSTO": "tipo_custo",
            "ENTRADA/SAIDA": "entrada_saida"
        }
        df_fin = df_fin.rename(columns=lambda c: cols_map.get(norm(c), c))
        
        # Normaliza colunas chave
        df_fin["tipo_custo_norm"] = df_fin["tipo_custo"].apply(norm)
        df_fin["entrada_norm"] = df_fin["entrada_saida"].apply(norm)
        df_fin["plano_norm"] = df_fin["plano_contas"].apply(norm)
        df_fin["mes_ano"] = df_fin["mes_ano"].apply(lambda x: str(x).strip() if x is not None else x)
        
        # Base completa
        df_base_all = df_fin.copy()
        df_base_all = df_base_all[~df_base_all["tipo_custo_norm"].isin(["NAO OPERACIONAL", "DISTRIBUICAO", "TRANSFERENCIA"])]
        
        # Análise de Despesas Fixas
        df_sem_simples = df_base_all[~df_base_all["plano_norm"].str.contains("SIMPLES NACIONAL", na=False)]
        df_despesas = df_sem_simples[df_sem_simples["entrada_norm"] == "SAIDA"]
        
        despesas_fixas = df_despesas[df_despesas["tipo_custo_norm"] == "FIXO"]
        despesas_fix_mes = despesas_fixas.groupby("mes_ano")["valor"].sum().abs().to_dict()
        
        # Amostra de registros fixos
        amostra_fixos = despesas_fixas[["data_mov", "valor", "plano_contas", "centro_custo", "mes_ano"]].head(5).to_dict(orient="records")
        
        # Verificação de chaves de mês
        meses_disponiveis = sorted(list(despesas_fix_mes.keys()))
        
        return {
            "status": "debug",
            "total_registros_brutos": len(df_fin),
            "total_despesas_operacionais": len(df_despesas),
            "total_despesas_fixas": len(despesas_fixas),
            "soma_despesas_fixas_por_mes": despesas_fix_mes,
            "meses_com_despesas_fixas": meses_disponiveis,
            "amostra_registros_fixos": amostra_fixos,
            "exemplo_mes_ano_formato": df_fin["mes_ano"].iloc[0] if not df_fin.empty else "N/A"
        }
    except Exception as e:
        import traceback
        return {"error": str(e), "traceback": traceback.format_exc()}

@app.get("/api/adiantamentos")
def get_adiantamentos(context: str = "flux", db: Client = Depends(get_db)):
    """
    Retorna saldos de adiantamentos (apenas cooperativa).
    """
    if context != "coop":
        return []
    try:
        return get_adiantamentos_coop(db)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/coop/resumo")
def get_coop_resumo(ano: Optional[str] = None, db: Client = Depends(get_db)):
    """
    Indicadores de capital e adiantamentos da Cooperativa.
    """
    try:
        fin = get_dre_financeiro_coop(db)
        df_fin = pd.DataFrame(fin)
        if not df_fin.empty:
            if ano:
                df_fin = df_fin[df_fin["mes_ano"].str.startswith(str(ano))]
            df_fin["plano_norm"] = df_fin["plano_contas"].apply(norm)
            cota_mask = df_fin["plano_norm"].str.contains("COTA|ENTRADA DE CAPITAL", na=False)
            entradas_cota = float(
                df_fin[cota_mask & (df_fin["entrada_saida"].str.upper() == "ENTRADA")]["valor"].sum()
            )
            saidas_cota = float(
                df_fin[cota_mask & (df_fin["entrada_saida"].str.upper().str.startswith("SA"))]["valor"].sum()
            )
        else:
            entradas_cota = saidas_cota = 0.0
        saldo_cota = entradas_cota + saidas_cota

        adi = get_adiantamentos_coop(db)
        df_adi = pd.DataFrame(adi)
        if not df_adi.empty:
            if ano:
                df_adi = df_adi[df_adi["mes_ano"].str.startswith(str(ano))]
            adiantado = float(df_adi.get("adiantado", pd.Series(dtype=float)).sum())
            reembolsado = float(df_adi.get("reembolsado", pd.Series(dtype=float)).sum())
            saldo_adi = float(df_adi.get("saldo", pd.Series(dtype=float)).sum())
        else:
            adiantado = reembolsado = saldo_adi = 0.0

        return {
            "entradas_cota": entradas_cota,
            "saidas_cota": saidas_cota,
            "saldo_cota": saldo_cota,
            "adiantado": adiantado,
            "reembolsado": reembolsado,
            "saldo_adiantamentos": saldo_adi,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/{full_path:path}")
async def serve_react_app(full_path: str):
    if full_path.startswith("api/"):
        raise HTTPException(status_code=404, detail="API endpoint not found")
    
    if os.path.exists(static_dir):
        file_path = os.path.join(static_dir, full_path)
        if os.path.exists(file_path) and os.path.isfile(file_path):
            return FileResponse(file_path)
        return FileResponse(os.path.join(static_dir, "index.html"))
    return {"message": "Frontend not built or dist directory missing"}
