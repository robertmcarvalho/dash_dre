import { useEffect, useMemo, useState } from "react";
import apiClient from "./apiClient";
import { formatCurrency } from "./utils/helpers";

function recommendedCashWeekStartForPayDay(payDayIso) {
  if (!payDayIso) return "";
  const d = new Date(`${payDayIso}T00:00:00`);
  if (Number.isNaN(d.getTime())) return "";
  const day = d.getDay(); // 0=Dom ... 6=Sab
  const mondayThisWeek = new Date(d);
  const diffToMonday = (day + 6) % 7;
  mondayThisWeek.setDate(d.getDate() - diffToMonday);
  return mondayThisWeek.toISOString().slice(0, 10);
}

function formatWeekLabel(weekStart, weekEnd) {
  if (!weekStart || !weekEnd) return "—";
  const [ys, ms, ds] = weekStart.split("-");
  const [ye, me, de] = weekEnd.split("-");
  return `${ds}/${ms}/${ys} a ${de}/${me}/${ye}`;
}

function formatDateLabel(isoDate) {
  if (!isoDate) return "—";
  const [y, m, d] = isoDate.split("-");
  return `${d}/${m}/${y}`;
}

function formatMonthLabel(ym) {
  if (!ym) return "—";
  const d = new Date(`${ym}-01T00:00:00`);
  if (Number.isNaN(d.getTime())) return ym;
  const label = new Intl.DateTimeFormat("pt-BR", { month: "long", year: "numeric" }).format(d);
  return label.charAt(0).toUpperCase() + label.slice(1);
}

export default function ConciliacaoEntregasView() {
  const [payMonths, setPayMonths] = useState([]);
  const [payMonth, setPayMonth] = useState("");
  const [payDays, setPayDays] = useState([]);
  const [payDay, setPayDay] = useState("");
  const [onlyDivergent, setOnlyDivergent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [showNoCyclePayments, setShowNoCyclePayments] = useState(false);
  const [data, setData] = useState(null);

  const payDayOptions = useMemo(() => {
    const unique = new Map();
    for (const d of payDays || []) {
      if (!d?.pay_day) continue;
      unique.set(d.pay_day, d);
    }
    return Array.from(unique.values()).sort((a, b) =>
      (a.pay_day || "").localeCompare(b.pay_day || "")
    );
  }, [payDays]);

  const payMonthOptions = useMemo(() => {
    const unique = new Map();
    for (const m of payMonths || []) {
      if (!m?.month) continue;
      unique.set(m.month, m);
    }
    return Array.from(unique.values()).sort((a, b) => (a.month || "").localeCompare(b.month || ""));
  }, [payMonths]);

  useEffect(() => {
    let mounted = true;
    (async () => {
      setError("");
      try {
        const pm = await apiClient.get("/api/coop/conciliacao_entregas/pay_months");
        if (!mounted) return;
        const pms = pm?.data || [];
        setPayMonths(pms);

        const lastPm = pms
          ?.slice()
          ?.sort((a, b) => (a.month || "").localeCompare(b.month || ""))
          .at(-1);
        if (lastPm?.month) setPayMonth(lastPm.month);
      } catch (e) {
        if (!mounted) return;
        setError(e?.response?.data?.detail || e?.message || "Erro ao carregar rodadas.");
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    if (!payMonth) return;
    let mounted = true;
    (async () => {
      setLoading(true);
      setError("");
      try {
        const pd = await apiClient.get("/api/coop/conciliacao_entregas/pay_days", {
          params: { month: payMonth },
        });
        if (!mounted) return;
        const pds = pd?.data || [];
        setPayDays(pds);

        const lastPd = pds
          ?.slice()
          ?.sort((a, b) => (a.pay_day || "").localeCompare(b.pay_day || ""))
          .at(-1);
        setPayDay(lastPd?.pay_day || "");
      } catch (e) {
        if (!mounted) return;
        setError(e?.response?.data?.detail || e?.message || "Erro ao carregar rodadas do mês.");
        setPayDays([]);
        setPayDay("");
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [payMonth]);

  useEffect(() => {
    if (!payDay) return;
    let mounted = true;
    (async () => {
      setLoading(true);
      setError("");
      try {
        const cashWeekStart = recommendedCashWeekStartForPayDay(payDay);
        const resp = await apiClient.get("/api/coop/conciliacao_entregas/report", {
          params: {
            cash_week_start: cashWeekStart,
            pay_day: payDay,
            only_divergent: onlyDivergent,
          },
        });
        if (!mounted) return;
        setData(resp.data);
      } catch (e) {
        if (!mounted) return;
        setError(e?.response?.data?.detail || e?.message || "Erro ao buscar conciliação.");
        setData(null);
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [payDay, onlyDivergent]);

  const computedCashWeekLabel = useMemo(() => {
    const ws = recommendedCashWeekStartForPayDay(payDay);
    if (!ws) return "—";
    const start = new Date(`${ws}T00:00:00`);
    if (Number.isNaN(start.getTime())) return "—";
    const end = new Date(start);
    end.setDate(start.getDate() + 6);
    const weekEnd = end.toISOString().slice(0, 10);
    return formatWeekLabel(ws, weekEnd);
  }, [payDay]);

  const totals = useMemo(() => {
    const receitaCiclos = data?.totals?.receita_ciclos_apurados || 0;
    const receitaCaixa = data?.totals?.receita_semana_caixa || 0;
    const pago = data?.totals?.pagamento_quinta || 0;
    const saldo = data?.totals?.saldo ?? (receitaCiclos - pago);
    const saldoCaixa = data?.totals?.saldo_caixa ?? (receitaCaixa - pago);
    return { receitaCiclos, receitaCaixa, pago, saldo, saldoCaixa };
  }, [data]);

  const repasseBadgeClass = (pct) => {
    const value = Number.isFinite(pct) ? pct : 0;
    if (value <= 70) return "bg-green-100 text-green-700";
    if (value <= 80) return "bg-yellow-100 text-yellow-800";
    return "bg-red-100 text-red-700";
  };

  const formatCyclesCompact = (cycles) => {
    const ranges = Array.from(
      new Set(
        (cycles || [])
          .map((c) => {
            const pi = (c?.periodo_inicio || "").slice(0, 10);
            const pf = (c?.periodo_fim || "").slice(0, 10);
            if (!pi || !pf) return null;
            return `${formatDateLabel(pi)} a ${formatDateLabel(pf)}`;
          })
          .filter(Boolean)
      )
    );
    if (!ranges.length) return { text: "—", title: "" };
    const shown = ranges.slice(0, 2).join(" • ");
    const extra = ranges.length > 2 ? ` +${ranges.length - 2}` : "";
    return { text: `${shown}${extra}`, title: ranges.join(" • ") };
  };

  const rows = useMemo(() => data?.rows || [], [data]);
  const noCyclePaymentRows = useMemo(
    () =>
      rows.filter((r) => (r?.pagamento_quinta || 0) > 0 && (r?.receita_ciclos_apurados || 0) <= 0),
    [rows]
  );
  const mainRows = useMemo(
    () =>
      rows.filter((r) => !((r?.pagamento_quinta || 0) > 0 && (r?.receita_ciclos_apurados || 0) <= 0)),
    [rows]
  );
  const mainRowsFiltered = useMemo(
    () => (mainRows || []).filter((r) => (r?.pagamento_quinta || 0) > 0),
    [mainRows]
  );
  const noCyclePaymentTotal = useMemo(
    () => noCyclePaymentRows.reduce((acc, r) => acc + (Number(r?.pagamento_quinta) || 0), 0),
    [noCyclePaymentRows]
  );

  return (
    <div className="p-6">
      <div className="flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold">Conferência semanal de receita e pagamento de entregadores</h1>
          </div>
        </div>

        <div className="bg-white rounded-xl p-4 border border-gray-100 flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-600">Mês:</span>
            <select
              className="border rounded-lg px-3 py-2 text-sm"
              value={payMonth}
              onChange={(e) => setPayMonth(e.target.value)}
            >
              {payMonthOptions.map((m) => (
                <option key={m.month} value={m.month}>
                  {formatMonthLabel(m.month)}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-600">Rodada (pagamento):</span>
            <select className="border rounded-lg px-3 py-2 text-sm" value={payDay} onChange={(e) => setPayDay(e.target.value)}>
              {payDayOptions.map((d) => (
                <option key={d.pay_day} value={d.pay_day}>
                  {formatDateLabel(d.pay_day)}
                </option>
              ))}
            </select>
          </div>

          <label className="flex items-center gap-2 text-sm text-gray-700">
            <input
              type="checkbox"
              checked={onlyDivergent}
              onChange={(e) => setOnlyDivergent(e.target.checked)}
            />
            Mostrar apenas divergências
          </label>

          <div className="ml-auto text-sm text-gray-500">
            Semana (Seg–Dom): {computedCashWeekLabel}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-blue-50 border border-blue-100 rounded-xl p-4 text-sm text-blue-900">
            <div className="font-semibold mb-1">Como ler a Receita</div>
            <div>
              “Receita Entregas (ciclos pagos)” = soma das entradas de entregas pela <span className="font-mono">DATA MOVIMENTO</span> dentro dos períodos apurados (<span className="font-mono">REFERENTE</span>) que aparecem na rodada.
              <div className="mt-1">
                “Caixa (semana)” = soma das entradas na semana (Seg–Dom) calculada a partir da rodada.
              </div>
            </div>
          </div>
          <div className="bg-amber-50 border border-amber-100 rounded-xl p-4 text-sm text-amber-900">
            <div className="font-semibold mb-1">Como ler o Pagamento</div>
            <div>“Pagamento Entregadores (rodada)” = o que será liberado no dia selecionado. Os ciclos apurados vêm do <span className="font-mono">REFERENTE</span>.</div>
          </div>
        </div>

        {error ? (
          <div className="bg-red-50 border border-red-200 text-red-700 rounded-xl p-4 text-sm">{error}</div>
        ) : null}

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-white rounded-xl p-4 border border-gray-100">
            <div className="text-xs text-gray-500">Receita Entregas (ciclos pagos)</div>
            <div className="text-xl font-semibold">{formatCurrency(totals.receitaCiclos)}</div>
            <div className="text-xs text-gray-500 mt-1">Caixa (semana selecionada): {formatCurrency(totals.receitaCaixa)}</div>
          </div>
          <div className="bg-white rounded-xl p-4 border border-gray-100">
            <div className="text-xs text-gray-500">Pagamento Entregadores (rodada)</div>
            <div className="text-xl font-semibold">{formatCurrency(totals.pago)}</div>
          </div>
          <div className="bg-white rounded-xl p-4 border border-gray-100">
            <div className="text-xs text-gray-500">Saldo (ciclo − pagamento)</div>
            <div className="text-xl font-semibold">{formatCurrency(totals.saldo)}</div>
            <div className="text-xs text-gray-500 mt-1">Saldo caixa (semana): {formatCurrency(totals.saldoCaixa)}</div>
          </div>
          <div className="bg-white rounded-xl p-4 border border-gray-100">
            <div className="text-xs text-gray-500">Controle rateio (pagamento)</div>
            <div className="text-sm text-gray-700">
              Mov: <span className="font-semibold">{formatCurrency(data?.controle?.pagamento_mov_total || 0)}</span>
            </div>
            <div className="text-sm text-gray-700">
              Rateado: <span className="font-semibold">{formatCurrency(data?.controle?.pagamento_rateado_total || 0)}</span>
            </div>
            <div className="text-sm text-gray-700">
              Dif.: <span className="font-semibold">{formatCurrency(data?.controle?.pagamento_diff || 0)}</span>
            </div>
          </div>
        </div>

        {noCyclePaymentRows.length ? (
          <div className="bg-white rounded-xl border border-gray-100 overflow-hidden">
            <div className="p-4 border-b border-gray-100 flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="font-semibold">Pagamentos sem receita do ciclo</div>
                <div className="text-xs text-gray-500">
                  {noCyclePaymentRows.length} farmácia(s) • Total pagamento: <span className="font-semibold">{formatCurrency(noCyclePaymentTotal)}</span>
                </div>
              </div>
              <button
                type="button"
                className="px-3 py-2 text-sm rounded-lg border border-gray-200 hover:bg-gray-50"
                onClick={() => setShowNoCyclePayments((v) => !v)}
              >
                {showNoCyclePayments ? "Ocultar" : "Mostrar"}
              </button>
            </div>

            {showNoCyclePayments ? (
              <div className="overflow-auto">
                <table className="min-w-full text-sm">
                  <thead className="bg-gray-50 text-gray-700">
                    <tr>
                      <th className="text-left px-4 py-3">Farmácia</th>
                      <th className="text-right px-4 py-3">Pagamento (rodada)</th>
                      <th className="text-left px-4 py-3">Ciclos</th>
                      <th className="text-left px-4 py-3">Obs.</th>
                    </tr>
                  </thead>
                  <tbody>
                    {noCyclePaymentRows
                      .slice()
                      .sort((a, b) => (b?.pagamento_quinta || 0) - (a?.pagamento_quinta || 0))
                      .map((r) => {
                        const cycles = formatCyclesCompact(r?.ciclos || []);
                        return (
                          <tr key={`no-cycle-${r.farmacia}`} className="border-t border-gray-100">
                            <td className="px-4 py-3 font-medium">{r.farmacia}</td>
                            <td className="px-4 py-3 text-right">{formatCurrency(r.pagamento_quinta || 0)}</td>
                            <td className="px-4 py-3 text-left">
                              <span className="text-xs text-gray-600" title={cycles.title || ""}>
                                {cycles.text}
                              </span>
                            </td>
                            <td className="px-4 py-3 text-left text-xs text-gray-600">
                              Pagamento encontrado, mas não localizamos receita de entregas dentro dos períodos apurados.
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
              </div>
            ) : null}
          </div>
        ) : null}

        <div className="bg-white rounded-xl border border-gray-100 overflow-hidden">
          <div className="p-4 border-b border-gray-100 flex items-center justify-between">
            <div className="font-semibold">Por farmácia</div>
            <div className="text-sm text-gray-500">{loading ? "Carregando..." : `${mainRowsFiltered.length} linhas`}</div>
          </div>

          <div className="overflow-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-gray-50 text-gray-700">
                <tr>
                  <th className="text-left px-4 py-3">Farmácia</th>
                  <th className="text-right px-4 py-3">Receita (ciclo)</th>
                  <th className="text-right px-4 py-3">Receita (caixa)</th>
                  <th className="text-right px-4 py-3">Pagamento (rodada)</th>
                  <th className="text-right px-4 py-3">Saldo</th>
                  <th className="text-right px-4 py-3">% Repasse</th>
                  <th className="text-left px-4 py-3">Ciclos</th>
                </tr>
              </thead>
              <tbody>
                {mainRowsFiltered.map((r) => {
                  const pct = Number.isFinite(r.pct_repasse) ? r.pct_repasse : 0;
                  const cycles = formatCyclesCompact(r.ciclos || []);
                  return (
                    <tr key={r.farmacia} className="border-t border-gray-100">
                      <td className="px-4 py-3 font-medium">{r.farmacia}</td>
                      <td className="px-4 py-3 text-right">{formatCurrency(r.receita_ciclos_apurados || 0)}</td>
                      <td className="px-4 py-3 text-right">{formatCurrency(r.receita_semana_caixa || 0)}</td>
                      <td className="px-4 py-3 text-right">{formatCurrency(r.pagamento_quinta || 0)}</td>
                      <td className="px-4 py-3 text-right">{formatCurrency(r.saldo || 0)}</td>
                      <td className="px-4 py-3 text-right">
                        <span className={`inline-flex px-2 py-1 rounded-full text-xs font-semibold ${repasseBadgeClass(pct)}`}>
                          {pct.toFixed(2)}%
                        </span>
                      </td>
                      <td className="px-4 py-3 text-left">
                        <span className="text-xs text-gray-600" title={cycles.title || ""}>
                          {cycles.text}
                        </span>
                      </td>
                    </tr>
                  );
                })}
                {!loading && mainRowsFiltered.length === 0 ? (
                  <tr>
                    <td className="px-4 py-6 text-gray-500" colSpan={7}>
                      Nenhum dado disponível para os filtros selecionados.
                    </td>
                  </tr>
                ) : null}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
